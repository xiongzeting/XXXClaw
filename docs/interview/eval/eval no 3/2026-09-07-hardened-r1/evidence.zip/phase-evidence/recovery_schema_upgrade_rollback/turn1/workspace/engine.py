import hashlib
import json
import os
from pathlib import Path


_FILES = ("a.json", "b.json", "version.json")


def _fault(fault, point):
    """Raise a requested fault before the associated commit."""
    if fault == point:
        raise RuntimeError(point)


def _write_json(root, name, value, fault=None):
    """Atomically commit one JSON state file, with public before/after hooks."""
    _fault(fault, "before_" + name)
    root.mkdir(parents=True, exist_ok=True)
    target = root / name
    temporary = root / ("." + name + ".tmp")
    payload = json.dumps(value, sort_keys=True, ensure_ascii=False)
    temporary.write_text(payload, encoding="utf-8")
    os.replace(temporary, target)
    _fault(fault, "after_" + name)


def _write_text(root, name, payload, fault=None, point_name=None):
    """Atomically commit a raw-text state file (used for the recovery journal)."""
    point_name = point_name or name
    _fault(fault, "before_" + point_name)
    root.mkdir(parents=True, exist_ok=True)
    target = root / name
    temporary = root / ("." + name + ".tmp")
    temporary.write_text(payload, encoding="utf-8")
    os.replace(temporary, target)
    _fault(fault, "after_" + point_name)


def _read_originals(root):
    originals = {}
    for name in _FILES:
        # read_bytes preserves the exact UTF-8 byte sequence used for hashing
        raw = (root / name).read_bytes()
        originals[name] = raw.decode("utf-8")
    return originals


def _load_json(text, label):
    try:
        return json.loads(text)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise ValueError("invalid " + label) from exc


def _recover(root, fault=None):
    journal_path = root / "backup.json"
    if not journal_path.exists():
        return None
    try:
        journal = _load_json(journal_path.read_text(encoding="utf-8"), "backup")
        originals = journal["files"]
        if set(originals) != set(_FILES) or any(type(originals[n]) is not str for n in _FILES):
            raise ValueError("invalid backup")
    except (KeyError, TypeError) as exc:
        raise ValueError("invalid backup") from exc

    # Each restore is itself a committed operation.  Keeping the journal until
    # all three commits finish makes a failed recovery safely retryable.
    for name in _FILES:
        _write_text(root, name, originals[name], fault, "recover_" + name)
    _fault(fault, "before_cleanup")
    journal_path.unlink()
    _fault(fault, "after_cleanup")
    return 1


def _upgrade(root, request, fault=None):
    # A journal means the previous upgrade did not finish.  It is not safe to
    # proceed from mixed-version files; callers explicitly use recover for it.
    if (root / "backup.json").exists():
        recovered = _recover(root, fault)
        if request.get("action") == "recover":
            return recovered

    version_data = _load_json((root / "version.json").read_text(encoding="utf-8"), "version")
    if type(version_data.get("version")) is not int:
        raise ValueError("schema")
    if version_data["version"] == 2:
        return 2
    if version_data["version"] != 1:
        raise ValueError("schema")

    originals = _read_originals(root)
    expected = request.get("expected_hashes")
    if expected is not None:
        if not isinstance(expected, dict):
            raise ValueError("checksum")
        for name, expected_hash in expected.items():
            if name not in originals or not isinstance(expected_hash, str):
                raise ValueError("checksum")
            actual_hash = hashlib.sha256(originals[name].encode("utf-8")).hexdigest()
            if actual_hash != expected_hash:
                raise ValueError("checksum")

    values = {}
    for name in _FILES[:2]:
        data = _load_json(originals[name], name)
        if type(data) is not dict or type(data.get("value")) is not int:
            raise ValueError("schema")
        values[name] = {"value": data["value"], "schema": 2}

    journal = {
        "files": originals,
        "hashes": {
            name: hashlib.sha256(originals[name].encode("utf-8")).hexdigest()
            for name in _FILES
        },
    }
    _write_json(root, "backup.json", journal, fault)
    for name in _FILES[:2]:
        _write_json(root, name, values[name], fault)
    _write_json(root, "version.json", {"version": 2}, fault)
    _fault(fault, "before_cleanup")
    (root / "backup.json").unlink()
    _fault(fault, "after_cleanup")
    return 2


def execute(root, request, fault=None):
    root = Path(root)
    if not isinstance(request, dict) or request.get("action") not in ("upgrade", "recover"):
        raise ValueError("action")
    if request["action"] == "recover":
        result = _recover(root, fault)
        if result is not None:
            return result
        # A completed upgrade is already in the requested terminal state.
        version = _load_json((root / "version.json").read_text(encoding="utf-8"), "version")
        if version.get("version") == 2:
            return 2
        return 1
    return _upgrade(root, request, fault)
