"""Input parsing for the configuration migration CLI."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class ConfigError(ValueError):
    """Raised when a configuration is not valid JSON data."""


def parse_json(text: str) -> dict[str, Any]:
    try:
        value = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ConfigError(f"invalid JSON: {exc.msg}") from exc
    if not isinstance(value, dict):
        raise ConfigError("configuration root must be an object")
    return value


def parse(source: str | Path) -> dict[str, Any]:
    path = Path(source)
    try:
        return parse_json(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ConfigError(f"unable to read {path}: {exc}") from exc


load = parse
parse_config = parse
