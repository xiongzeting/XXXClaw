import copy
import math


_ZONE_BASE = {
    "local": 500,
    "regional": 700,
    "national": 900,
}
_BAND_PRICE = 200
_FRAGILE_SURCHARGE = 150
_AMENDMENT_FIELDS = {"group_id", "weight_g", "zone", "fragile", "free"}


def _true_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def _canonical(value):
    if isinstance(value, dict):
        return tuple(sorted((key, _canonical(item)) for key, item in value.items()))
    if isinstance(value, list):
        return tuple(_canonical(item) for item in value)
    return value


def _validate_package(package):
    if not isinstance(package, dict):
        raise ValueError("package must be an object")
    package_id = package.get("id")
    if not isinstance(package_id, str):
        raise ValueError("id must be a string")
    weight = package.get("weight_g")
    if not _true_int(weight) or weight <= 0:
        raise ValueError("weight_g must be a positive integer")
    zone = package.get("zone")
    if zone not in _ZONE_BASE:
        raise ValueError("unknown zone")
    if "fragile" in package and not isinstance(package["fragile"], bool):
        raise ValueError("fragile must be boolean")
    if "group_id" in package and package["group_id"] is not None:
        if not isinstance(package["group_id"], str):
            raise ValueError("group_id must be a string or null")


def _apply_amendments(data, packages):
    amendments = data.get("amendments", [])
    if not isinstance(amendments, list):
        raise ValueError("amendments must be a list")

    by_id = {package["id"]: package for package in packages}
    selected = {}
    for amendment in amendments:
        if not isinstance(amendment, dict):
            raise ValueError("amendment must be an object")
        amendment_id = amendment.get("amendment_id")
        revision = amendment.get("revision")
        package_id = amendment.get("package_id")
        if not isinstance(amendment_id, str) or not _true_int(revision) or revision < 0:
            raise ValueError("invalid amendment identity")
        if not isinstance(package_id, str):
            raise ValueError("invalid amendment package_id")
        if "set" not in amendment or not isinstance(amendment["set"], dict):
            raise ValueError("amendment set must be an object")
        if any(key not in _AMENDMENT_FIELDS for key in amendment["set"]):
            raise ValueError("unknown amendment field")
        if "free" in amendment["set"] and not isinstance(amendment["set"]["free"], bool):
            raise ValueError("free must be boolean")
        withdrawn = amendment.get("withdrawn", False)
        if not isinstance(withdrawn, bool):
            raise ValueError("withdrawn must be boolean")

        key = (amendment_id, revision)
        signature = _canonical(amendment)
        if package_id not in by_id:
            raise ValueError("amendment references unknown package")
        if key in selected and selected[key][0] != signature:
            raise ValueError("conflicting amendment revision")
        selected[key] = (signature, amendment)

    effective = {}
    for (amendment_id, revision), (_, amendment) in selected.items():
        old = effective.get(amendment_id)
        if old is None or revision > old[0]:
            effective[amendment_id] = (revision, amendment)

    ordered = sorted(
        (revision, amendment_id, amendment)
        for amendment_id, (revision, amendment) in effective.items()
    )
    for _, _, amendment in ordered:
        if amendment.get("withdrawn", False):
            continue
        package_id = amendment["package_id"]
        if package_id not in by_id:
            raise ValueError("amendment references unknown package")
        package = by_id[package_id]
        for field, value in amendment["set"].items():
            if field == "free":
                continue
            package[field] = value
        _validate_package(package)
    return effective


def solve(data):
    if not isinstance(data, dict):
        raise ValueError("data must be an object")

    packages = data.get("packages", [])
    if not isinstance(packages, list):
        raise ValueError("packages must be a list")
    packages = copy.deepcopy(packages)

    free_ids = data.get("free_ids", [])
    if not isinstance(free_ids, list):
        raise ValueError("free_ids must be a list")
    if any(not isinstance(package_id, str) for package_id in free_ids):
        raise ValueError("free_ids must contain strings")
    free_set = set(free_ids)

    cap = data.get("cap_cents", None)
    if cap is not None and (not _true_int(cap) or cap < 0):
        raise ValueError("cap_cents must be a non-negative integer or null")

    group_caps = data.get("group_caps", {})
    if not isinstance(group_caps, dict):
        raise ValueError("group_caps must be an object")
    for group, group_cap in group_caps.items():
        if not isinstance(group, str) or not _true_int(group_cap) or group_cap < 0:
            raise ValueError("invalid group cap")

    seen = set()
    for package in packages:
        _validate_package(package)
        package_id = package["id"]
        if package_id in seen:
            raise ValueError("duplicate id")
        seen.add(package_id)

    # Amendments operate on private copies and may change all mutable package
    # attributes except the package identity itself.
    effective = _apply_amendments(data, packages)
    for amendment_id, (_, amendment) in effective.items():
        if amendment.get("withdrawn", False):
            continue
        package_id = amendment["package_id"]
        if "free" in amendment["set"]:
            free = amendment["set"]["free"]
            if not isinstance(free, bool):
                raise ValueError("free must be boolean")
            if free:
                free_set.add(package_id)
            else:
                free_set.discard(package_id)

    charges = []
    for package in packages:
        package_id = package["id"]
        amount = _ZONE_BASE[package["zone"]] + max(
            0, math.ceil(package["weight_g"] / 1000) - 1
        ) * _BAND_PRICE
        if package.get("fragile"):
            amount += _FRAGILE_SURCHARGE
        if package_id in free_set:
            amount = 0
        charges.append({
            "id": package_id,
            "shipping_cents": amount,
            "group_id": package.get("group_id"),
        })

    # Apply each configured group cap independently, in package-id order.
    for group, group_cap in group_caps.items():
        remaining = group_cap
        for item in sorted(
            (item for item in charges if item["group_id"] == group),
            key=lambda item: item["id"],
        ):
            kept = min(item["shipping_cents"], remaining)
            item["shipping_cents"] = kept
            remaining -= kept

    if cap is not None:
        remaining = cap
        for item in sorted(charges, key=lambda item: item["id"]):
            kept = min(item["shipping_cents"], remaining)
            item["shipping_cents"] = kept
            remaining -= kept

    amounts = {item["id"]: item["shipping_cents"] for item in charges}
    return [{"id": package["id"], "shipping_cents": amounts[package["id"]]} for package in packages]
