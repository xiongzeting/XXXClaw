"""UTF-8 JSON parsing."""
import json


def parse(text):
    if not isinstance(text, str):
        raise ValueError("input")
    try:
        value = json.loads(text)
    except (TypeError, ValueError) as exc:
        raise ValueError("json") from exc
    return value
