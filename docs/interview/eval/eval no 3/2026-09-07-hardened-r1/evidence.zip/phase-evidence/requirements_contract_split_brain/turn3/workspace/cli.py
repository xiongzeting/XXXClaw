import json
import os
import sys
import tempfile
from pathlib import Path

from solution import solve


def main():
    if len(sys.argv) != 3:
        return 2

    input_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    try:
        data = json.loads(input_path.read_text(encoding="utf-8"))
        result = solve(data)
        rendered = json.dumps(
            result, ensure_ascii=False, separators=(",", ":"), sort_keys=True
        )

        def has_business_error(value):
            if isinstance(value, dict):
                if isinstance(value.get("status"), int) and value["status"] >= 400:
                    return True
                return False
            if isinstance(value, list):
                return any(has_business_error(item) for item in value)
            return False

        # Business responses are fully computed and serialized, but are not
        # committed as successful CLI output.
        if has_business_error(result):
            return 1

        # Prepare the complete replacement beside the destination, then swap
        # it in one operation.  No destination bytes are touched on failure.
        output_path.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(
            prefix="." + output_path.name + ".", dir=str(output_path.parent)
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as stream:
                stream.write(rendered)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, output_path)
        except Exception:
            try:
                os.unlink(temporary)
            except OSError:
                pass
            raise
        return 0
    except (ValueError, OSError, TypeError, json.JSONDecodeError, UnicodeError):
        return 1


if __name__ == "__main__":
    sys.exit(main())
