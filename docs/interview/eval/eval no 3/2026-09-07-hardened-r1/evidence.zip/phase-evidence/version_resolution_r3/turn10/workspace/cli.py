import json
import os
import sys
import tempfile
from pathlib import Path

from solution import solve


def main():
    if len(sys.argv) != 3:
        return 2
    input_path, output_path = sys.argv[1], sys.argv[2]
    try:
        data = json.loads(Path(input_path).read_text(encoding="utf-8"))
        result = solve(data)
        payload = json.dumps(
            result, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")

        destination = Path(output_path)
        parent = destination.parent
        fd, temporary = tempfile.mkstemp(prefix="." + destination.name + ".", dir=str(parent))
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, output_path)
            temporary = None
        finally:
            if temporary is not None:
                try:
                    os.unlink(temporary)
                except FileNotFoundError:
                    pass
        return 0
    except (ValueError, OSError, UnicodeError, TypeError):
        return 1


if __name__ == "__main__":
    sys.exit(main())
