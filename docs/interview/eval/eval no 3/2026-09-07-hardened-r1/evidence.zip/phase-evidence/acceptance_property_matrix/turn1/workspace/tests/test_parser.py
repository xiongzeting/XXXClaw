import json

import pytest

from parser import parse


def test_empty_text_returns_empty_mapping():
    assert parse("") == {}


def test_parses_json_value_types():
    result = parse(
        'string="value"\n'
        'integer=42\n'
        'negative=-7\n'
        'boolean=true\n'
        'null=null\n'
        'array=[1, false, "x"]\n'
        'object={"nested": 1}'
    )

    assert result == {
        "string": "value",
        "integer": 42,
        "negative": -7,
        "boolean": True,
        "null": None,
        "array": [1, False, "x"],
        "object": {"nested": 1},
    }
    assert type(result["boolean"]) is bool
    assert type(result["integer"]) is int


def test_integer_precision_is_preserved():
    value = 10**1000 + 123456789

    result = parse(f"large={value}")

    assert result["large"] == value
    assert type(result["large"]) is int


def test_first_equals_sign_separates_key_from_json_value():
    assert parse('key="left=right"') == {"key": "left=right"}


def test_keys_are_not_trimmed_or_unicode_normalized():
    composed = "é"
    decomposed = "e\u0301"

    result = parse(f" key ={json.dumps(composed)}\n{composed}=1\n{decomposed}=2")

    assert result[" key "] == "é"
    assert result[composed] == 1
    assert result[decomposed] == 2
    assert len(result) == 3


@pytest.mark.parametrize(
    "text",
    [
        "=1",  # empty key
        "key=1\nkey=2",  # repeated raw key
        "key",  # missing separator
        "key=",  # missing JSON value
        "key={",  # malformed JSON
        "key=NaN",
        "key=Infinity",
        "key=-Infinity",
    ],
)
def test_rejects_invalid_entries(text):
    with pytest.raises(ValueError):
        parse(text)


def test_distinct_keys_that_differ_only_by_whitespace_are_not_duplicates():
    assert parse("a=1\n a=2") == {"a": 1, " a": 2}
