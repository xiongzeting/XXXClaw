# MiniClaw Long-term Memory

Human-maintained notes outside the managed block are preserved.

<!-- miniclaw-managed-memory:start -->
## MiniClaw Managed Semantic Memory

### preference
- (none)

### project
- (none)

### environment
- (none)

### fact
- (none)

<!-- miniclaw-managed-memory:end -->
