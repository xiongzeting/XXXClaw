import hashlib
import json
import subprocess
import sys
from pathlib import Path

import release


def test_recursive_manifest_filters_and_sorts(tmp_path):
    source = tmp_path / "src"
    (source / "z" / "nested").mkdir(parents=True)
    (source / "a.py").write_bytes(b"a")
    (source / "z" / "nested" / "b.py").write_bytes(b"b")
    (source / ".hidden.py").write_bytes(b"ignored")
    (source / "z" / "nested" / "x.txt").write_bytes(b"ignored")
    (source / "__pycache__").mkdir()
    (source / "__pycache__" / "cached.py").write_bytes(b"ignored")
    (source / "z" / "link.py").symlink_to(source / "a.py")
    (source / "z" / "linkdir").symlink_to(source / "z" / "nested", target_is_directory=True)

    output = tmp_path / "manifest.json"
    release.build_manifest(source, output)

    assert json.loads(output.read_text()) == {
        "a.py": hashlib.sha256(b"a").hexdigest(),
        "z/nested/b.py": hashlib.sha256(b"b").hexdigest(),
    }
    assert release.verify_manifest(source, output) is True


def test_verify_detects_changes_and_unsafe_paths(tmp_path):
    source = tmp_path / "src"
    source.mkdir()
    file = source / "a.py"
    file.write_text("a")
    output = tmp_path / "manifest.json"
    release.build_manifest(source, output)

    file.write_text("changed")
    assert release.verify_manifest(source, output) is False
    output.write_text('{"../a.py":"' + hashlib.sha256(b"a").hexdigest() + '"}')
    assert release.verify_manifest(source, output) is False


def test_update_replaces_tree_exactly_and_handles_directory_names(tmp_path):
    source = tmp_path / "src"
    (source / "old").mkdir(parents=True)
    (source / "same.py").write_text("old")
    (source / "old" / "same.py").write_text("nested")
    output = tmp_path / "manifest.json"
    release.build_manifest(source, output)

    (source / "same.py").rename(source / "new.py")
    (source / "old" / "same.py").unlink()
    (source / "old").rmdir()
    (source / "new.py").write_text("new")
    release.update_manifest(source, output)

    assert json.loads(output.read_text()) == {
        "new.py": hashlib.sha256(b"new").hexdigest(),
    }


def test_failed_update_preserves_old_manifest(tmp_path):
    source = tmp_path / "src"
    source.mkdir()
    (source / "a.py").write_text("a")
    output = tmp_path / "manifest.json"
    release.build_manifest(source, output)
    old = output.read_bytes()

    (source / "broken.py").symlink_to(source / "missing.py")
    # A missing source root must not replace an existing manifest.
    try:
        release.update_manifest(tmp_path / "missing", output)
    except ValueError:
        pass
    assert output.read_bytes() == old


def test_cli_status_codes(tmp_path):
    source = tmp_path / "src"
    source.mkdir()
    (source / "a.py").write_text("a")
    output = tmp_path / "manifest.json"
    script = Path(__file__).parents[1] / "release.py"

    build = subprocess.run([sys.executable, str(script), "build", str(source), str(output)])
    verify = subprocess.run([sys.executable, str(script), "verify", str(source), str(output)])
    update = subprocess.run([sys.executable, str(script), "update", str(source), str(output)])
    bad_args = subprocess.run([sys.executable, str(script), "unknown", str(source), str(output)])

    assert build.returncode == 0
    assert verify.returncode == 0
    assert update.returncode == 0
    assert bad_args.returncode == 2
