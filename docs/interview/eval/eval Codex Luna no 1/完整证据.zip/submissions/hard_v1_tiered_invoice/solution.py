def _charge(units):
    first = min(units, 10)
    second = min(max(units - 10, 0), 10)
    remainder = max(units - 20, 0)
    return first * 100 + second * 80 + remainder * 50


def solve(data):
    discount = data.get("discount_cents", 0)
    if type(discount) is not int or discount < 0:
        raise ValueError("discount_cents must be a non-negative integer")

    prepared = []
    seen_ids = set()
    for line in data["lines"]:
        line_id = line["id"]
        if line_id in seen_ids:
            raise ValueError("line ids must be unique")
        seen_ids.add(line_id)

        units = line["units"]
        if type(units) is not int or units < 0:
            raise ValueError("units must be a non-negative integer")
        prepared.append((line_id, _charge(units), line["exempt"]))

    result_lines = []
    remaining_discount = discount
    for line_id, charge, exempt in sorted(prepared, key=lambda item: item[0]):
        base = max(charge - remaining_discount, 0)
        remaining_discount = max(remaining_discount - charge, 0)
        tax = 0 if exempt else (base * 7 + 50) // 100
        total = base + tax
        result_lines.append({
            "id": line_id,
            "base_cents": base,
            "tax_cents": tax,
            "total_cents": total,
        })

    return {
        "lines": result_lines,
        "grand_total_cents": sum(line["total_cents"] for line in result_lines),
    }
