"""Version-constrained dependency selection."""

import re
from functools import total_ordering

_VERSION_RE = re.compile(
    r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)"
    r"(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?"
    r"(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$"
)


@total_ordering
class _Version:
    __slots__ = ("text", "major", "minor", "patch", "pre")

    def __init__(self, text):
        if not isinstance(text, str):
            raise ValueError("version must be a string")
        match = _VERSION_RE.fullmatch(text)
        if match is None:
            raise ValueError("invalid version")
        self.text = text
        self.major, self.minor, self.patch = (int(match.group(i)) for i in (1, 2, 3))
        raw = match.group(4)
        self.pre = () if raw is None else tuple(
            int(part) if part.isdigit() else part for part in raw.split(".")
        )
        if raw is not None:
            for parsed, original in zip(self.pre, raw.split(".")):
                if isinstance(parsed, int) and str(parsed) != original:
                    raise ValueError("invalid version")

    def _key(self):
        if not self.pre:
            pre = (1,)
        else:
            pre = (0, tuple(
                (0, item) if isinstance(item, int) else (1, item)
                for item in self.pre
            ))
        return self.major, self.minor, self.patch, pre

    def __eq__(self, other):
        return isinstance(other, _Version) and self._key() == other._key()

    def __lt__(self, other):
        if not isinstance(other, _Version):
            return NotImplemented
        return self._key() < other._key()

    def __hash__(self):
        return hash(self._key())


def _parse_versions(values, label):
    if not isinstance(values, list):
        raise ValueError(label + " must be an array")
    result = []
    for value in values:
        try:
            result.append((value, _Version(value)))
        except (TypeError, ValueError) as exc:
            raise ValueError("invalid version in " + label) from exc
    return result


def _parse_range(item):
    if not isinstance(item, dict):
        raise ValueError("requirement must be an object")
    name = item.get("name")
    minimum = item.get("min")
    maximum = item.get("max")
    if not isinstance(name, str) or not isinstance(minimum, str):
        raise ValueError("invalid requirement")
    try:
        lower = _Version(minimum)
        upper = None if maximum is None else _Version(maximum)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid requirement version") from exc
    if upper is not None and lower >= upper:
        raise ValueError("empty version range")
    return name, lower, upper


def _add_constraint(constraints, name, lower, upper):
    previous = constraints.get(name)
    if previous is None:
        constraints[name] = (lower, upper)
        return
    old_lower, old_upper = previous
    if lower > old_lower:
        old_lower = lower
    if old_upper is None or (upper is not None and upper < old_upper):
        old_upper = upper
    if old_upper is not None and old_lower >= old_upper:
        raise ValueError("empty version intersection")
    constraints[name] = (old_lower, old_upper)


def solve(data):
    if not isinstance(data, dict):
        raise ValueError("data must be an object")
    catalog = data.get("catalog")
    requirements = data.get("requirements")
    yanked = data.get("yanked", {})
    dependencies = data.get("dependencies", {})
    if not isinstance(catalog, dict) or not isinstance(requirements, list):
        raise ValueError("invalid input")
    if not isinstance(yanked, dict) or not isinstance(dependencies, dict):
        raise ValueError("invalid input")

    parsed_catalog = {}
    for name, values in catalog.items():
        if not isinstance(name, str):
            raise ValueError("component name must be a string")
        parsed_catalog[name] = _parse_versions(values, "catalog")

    parsed_yanked = {}
    for name, values in yanked.items():
        if not isinstance(name, str):
            raise ValueError("component name must be a string")
        parsed_yanked[name] = {text for text, _ in _parse_versions(values, "yanked")}

    # Parse and validate every dependency entry before solving, including
    # entries for components or versions that cannot ultimately be selected.
    parsed_dependencies = {}
    for name, by_version in dependencies.items():
        if not isinstance(name, str) or not isinstance(by_version, dict):
            raise ValueError("invalid dependencies")
        parsed_dependencies[name] = {}
        for version, dep_requirements in by_version.items():
            _Version(version)
            if not isinstance(dep_requirements, list):
                raise ValueError("dependency requirements must be an array")
            parsed_dependencies[name][version] = [_parse_range(req) for req in dep_requirements]

    initial = {}
    for item in requirements:
        name, lower, upper = _parse_range(item)
        _add_constraint(initial, name, lower, upper)

    # Preserve the first spelling when equivalent version values occur.
    candidate_cache = {}
    for name, values in parsed_catalog.items():
        seen = {}
        for text, version in values:
            if text in parsed_yanked.get(name, set()):
                continue
            seen.setdefault(version, text)
        candidate_cache[name] = sorted(
            ((version, text) for version, text in seen.items()),
            key=lambda pair: pair[0], reverse=True,
        )

    for name in initial:
        if name not in parsed_catalog:
            raise ValueError("unknown component")
        if not candidate_cache[name]:
            raise ValueError("no candidate version")

    names = sorted(parsed_catalog)
    best = None

    def vector(assignment):
        return tuple(
            (-1, -1, -1, (-1,)) if name not in assignment else assignment[name]._key()
            for name in names
        )

    def search(constraints, assignment):
        nonlocal best
        # Every assigned value must satisfy all constraints currently known.
        for name, version in assignment.items():
            lower, upper = constraints[name]
            if version < lower or (upper is not None and version >= upper):
                return

        pending = [name for name in constraints if name not in assignment]
        if not pending:
            current_vector = vector(assignment)
            if best is None or current_vector > best[0]:
                best = (current_vector, dict(assignment))
            return

        # Most constrained component first reduces the global search space;
        # choices themselves remain descending for deterministic traversal.
        def options(name):
            lower, upper = constraints[name]
            return [
                (version, text) for version, text in candidate_cache[name]
                if version >= lower and (upper is None or version < upper)
            ]

        chosen = min(pending, key=lambda item: len(options(item)))
        choices = options(chosen)
        if not choices:
            return
        for version, text in choices:
            next_constraints = dict(constraints)
            next_assignment = dict(assignment)
            next_assignment[chosen] = version
            valid = True
            for dep_name, lower, upper in parsed_dependencies.get(chosen, {}).get(text, []):
                if dep_name not in parsed_catalog:
                    valid = False
                    break
                try:
                    _add_constraint(next_constraints, dep_name, lower, upper)
                except ValueError:
                    valid = False
                    break
            if valid:
                search(next_constraints, next_assignment)

    search(initial, {})
    if best is None:
        raise ValueError("no globally satisfying selection")
    # Only the dependency closure (the assigned components) is emitted.
    return {name: best[1][name].text for name in best[1]}
