import json


def load(text):
    """Decode one JSON document and return its value."""
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError) as exc:
        raise ValueError("invalid JSON") from exc


def object_value(value, name):
    if type(value) is not dict:
        raise ValueError(f"{name} must be an object")
    return value


def list_value(value, name):
    if type(value) is not list:
        raise ValueError(f"{name} must be an array")
    return value


def text_value(value, name):
    if type(value) is not str or not value:
        raise ValueError(f"{name} must be a non-empty string")
    return value
