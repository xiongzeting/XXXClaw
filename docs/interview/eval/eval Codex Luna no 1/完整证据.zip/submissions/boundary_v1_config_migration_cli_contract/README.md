# Schema migration

Migrate a schema 1 JSON configuration to schema 2:

```text
python migrate.py input.json [output.json]
```

Exit status is `0` on success, `1` for input, JSON, schema, conflict, or
output errors, and `2` for invalid command-line arguments.

Every `services` array is traversed recursively. Each service's `host` and
`port` become an `endpoint` (`host:port`); unknown fields are preserved.
Existing `endpoint` fields and incomplete or conflicting `host`/`port` data
are rejected. The output is written atomically.
