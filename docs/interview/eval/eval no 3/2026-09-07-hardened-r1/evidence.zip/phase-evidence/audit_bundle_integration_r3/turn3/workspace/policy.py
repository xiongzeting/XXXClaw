"""Authorization policy evaluation. Deny always wins."""


def authorize(event, policies):
    matches = [p for p in policies
               if p["tenant"] == event["tenant"]
               and p["_start"] <= event["_time"] < p["_end"]
               and p["user"] in ("*", event["user"])
               and p["action"] in ("*", event["action"])]
    if not matches or any(p["decision"] == "deny" for p in matches):
        raise ValueError("denied")
    return True


def authorize_all(events, policies):
    for event in events:
        authorize(event, policies)
    return events
