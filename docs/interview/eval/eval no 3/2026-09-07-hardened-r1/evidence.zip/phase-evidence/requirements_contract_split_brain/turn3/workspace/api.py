"""Version-aware response adapter."""

from solution import solve


def respond(item):
    """Respond to one request; an omitted version means v1."""
    return solve(item)
