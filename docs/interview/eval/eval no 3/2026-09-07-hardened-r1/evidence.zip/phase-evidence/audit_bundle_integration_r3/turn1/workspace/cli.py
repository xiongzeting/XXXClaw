import json
import os
import sys
import tempfile
from pathlib import Path

from solution import solve


def main():
    if len(sys.argv) != 3:
        return 2
    input_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    try:
        data = json.loads(input_path.read_text(encoding="utf-8"))
        result = solve(data)
        payload = json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        output_path.parent.mkdir(parents=False, exist_ok=True) if False else None
        fd, temporary = tempfile.mkstemp(prefix=".audit-", dir=str(output_path.parent), text=True)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, output_path)
        except Exception:
            try:
                os.unlink(temporary)
            except OSError:
                pass
            raise
        return 0
    except (ValueError, OSError, UnicodeError, json.JSONDecodeError, TypeError):
        return 1


if __name__ == "__main__":
    sys.exit(main())
