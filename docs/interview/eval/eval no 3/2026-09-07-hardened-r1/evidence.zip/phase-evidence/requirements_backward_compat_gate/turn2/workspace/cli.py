#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
import sys


def load_items():
    with (Path(__file__).resolve().parent / "data.json").open(encoding="utf-8") as f:
        data = json.load(f)
    return {item["id"]: item["value"] for item in data["items"]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("id")
    parser.add_argument("--format", choices=("text", "json"), default="text")
    args = parser.parse_args()

    items = load_items()
    if args.id not in items:
        if args.format == "json":
            print(json.dumps({"error": "missing", "id": args.id}, separators=(",", ":")))
        else:
            print(f"missing: {args.id}", file=sys.stderr)
        return 1

    if args.format == "json":
        print(json.dumps({"id": args.id, "value": items[args.id]}, separators=(",", ":")))
    else:
        print(f"{args.id}={items[args.id]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
