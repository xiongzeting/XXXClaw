"""Public solution API for the JSON audit aggregation task."""
from audit import audit


def solve(data):
    """Return a deterministic result without modifying the caller's object."""
    return audit(data)
