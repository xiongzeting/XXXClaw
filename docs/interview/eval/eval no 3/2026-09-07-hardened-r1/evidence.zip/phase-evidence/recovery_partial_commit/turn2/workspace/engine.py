import copy
import json
import os
from pathlib import Path


def load(root, name, default):
    path = Path(root) / name
    if not path.exists():
        return copy.deepcopy(default)
    return json.loads(path.read_text('utf-8'))


def save(root, name, data, fault=None, point=None):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    path = root / name
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(
        json.dumps(data, sort_keys=True, ensure_ascii=False),
        'utf-8',
    )
    os.replace(temporary, path)
    if fault is not None and fault == point:
        raise RuntimeError(point)


def _validate_request(request):
    if not isinstance(request, dict):
        raise ValueError('request')
    required = {'batch_id', 'attempt_id', 'amounts', 'action'}
    if set(request) != required:
        raise ValueError('request')
    if request['action'] not in {'commit', 'restore'}:
        raise ValueError('action')
    amounts = request['amounts']
    if (not isinstance(amounts, dict)
            or set(amounts) != {'t1', 't2', 't3'}
            or any(type(value) is not int or value <= 0
                   for value in amounts.values())):
        raise ValueError('amounts')


def batch(root, request, fault=None):
    _validate_request(request)
    key = request['batch_id']
    aid = str(request['attempt_id'])
    payload = copy.deepcopy(request['amounts'])
    state = load(root, 'batches.json', {})

    if key not in state:
        state[key] = {'payload': payload, 'attempts': {}}
    row = state[key]
    if row.get('payload') != payload:
        raise ValueError('payload conflict')
    attempts = row.setdefault('attempts', {})

    if aid not in attempts:
        if any(status == 'pending' for status in attempts.values()):
            raise ValueError('unfinished attempt')
        attempts[aid] = 'pending'
        # A first commit is made durable before any tenant ledger operation.
        save(root, 'batches.json', state)

    status = attempts[aid]
    if request['action'] == 'restore':
        if status == 'committed':
            raise ValueError('committed')
        if status == 'compensated':
            return 'all_pending'

        for tenant in sorted(payload):
            ledger = load(root, tenant + '.json', {})
            commit_op = f'{key}/{aid}/commit'
            compensate_op = f'{key}/{aid}/compensate'
            if commit_op not in ledger or compensate_op in ledger:
                continue
            ledger[compensate_op] = -ledger[commit_op]
            save(root, tenant + '.json', ledger, fault,
                 'compensate_' + tenant)
        attempts[aid] = 'compensated'
        save(root, 'batches.json', state)
        return 'all_pending'

    if status == 'committed':
        return 'committed'
    if status == 'compensated':
        return 'all_pending'

    for tenant, amount in sorted(payload.items()):
        if fault == 'before_' + tenant:
            raise RuntimeError(fault)
        ledger = load(root, tenant + '.json', {})
        op = f'{key}/{aid}/commit'
        if op not in ledger:
            ledger[op] = amount
            save(root, tenant + '.json', ledger, fault, 'after_' + tenant)

    attempts[aid] = 'committed'
    save(root, 'batches.json', state)
    return 'committed'


execute = batch
