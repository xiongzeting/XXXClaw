import copy, json, os
from pathlib import Path


def load(root, name, default):
    p = Path(root) / name
    return json.loads(p.read_text('utf-8')) if p.exists() else copy.deepcopy(default)


def save(root, name, data, fault=None, point=None):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    if fault is not None and fault == 'before_commit':
        raise RuntimeError(fault)
    p = root / name
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, sort_keys=True, ensure_ascii=False), 'utf-8')
    os.replace(tmp, p)
    if fault is not None and fault == point:
        raise RuntimeError(point)


def worker(root, event, fault=None):
    state = load(root, 'worker.json', {'events': {}, 'orders': {}, 'effects': []})

    if not isinstance(event, dict):
        raise ValueError('event')
    try:
        tenant = event['tenant']
        event_id = event['event_id']
        order_id = event['order_id']
        seq = event['seq']
        amount = event['amount']
    except (KeyError, TypeError):
        raise ValueError('event')
    if type(seq) is not int or seq < 1 or type(amount) is not int:
        raise ValueError('event')

    key = json.dumps([tenant, event_id])
    order = json.dumps([tenant, order_id])

    existing = state['events'].get(key)
    if existing is not None:
        if existing != event:
            raise ValueError('conflict')
        # A byte-for-byte business duplicate is idempotent; retain its state.
    else:
        # Two different event identities cannot occupy one order sequence.
        for saved in state['events'].values():
            if (saved['tenant'], saved['order_id'], saved['seq']) == (tenant, order_id, seq):
                raise ValueError('sequence conflict')
        state['events'][key] = copy.deepcopy(event)

    row = state['orders'].setdefault(order, {'seq': 0, 'total': 0})
    # Once a gap is filled, apply every now-contiguous event, not just the
    # event from the current request.
    while True:
        next_seq = row['seq'] + 1
        candidate = next(
            (saved for saved in state['events'].values()
             if saved['tenant'] == tenant
             and saved['order_id'] == order_id
             and saved['seq'] == next_seq),
            None,
        )
        if candidate is None:
            break
        effect = [candidate['tenant'], candidate['event_id']]
        if effect in state['effects']:
            row['seq'] = next_seq
            continue
        row['seq'] = next_seq
        row['total'] += candidate['amount']
        state['effects'].append(effect)

    save(root, 'worker.json', state, fault, 'after_commit')
    return copy.deepcopy(row)


execute = worker
