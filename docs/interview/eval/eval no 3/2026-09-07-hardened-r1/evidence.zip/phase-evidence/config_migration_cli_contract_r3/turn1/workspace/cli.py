"""Command-line interface: INPUT OUTPUT."""
import sys
from pathlib import Path

from package.parser import parse
from package.storage import save
from solution import solve


def main():
    if len(sys.argv) != 3:
        return 2
    try:
        text = Path(sys.argv[1]).read_text(encoding="utf-8")
        data = parse(text)
        result = solve(data)
        save(sys.argv[2], result)
    except (OSError, UnicodeError, ValueError, TypeError):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
