"""Schema migrations."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from .parser import ConfigError


def _visit(value: Any) -> None:
    if isinstance(value, list):
        for item in value:
            _visit(item)
        return
    if not isinstance(value, dict):
        return

    services = value.get("services")
    if services is not None:
        if not isinstance(services, list):
            raise ConfigError("services must be an array")
        for index, service in enumerate(services):
            if not isinstance(service, dict):
                raise ConfigError(f"services[{index}] must be an object")
            _migrate_service(service, index)

    for key, child in value.items():
        if key != "services":
            _visit(child)


def _migrate_service(service: dict[str, Any], index: int) -> None:
    has_endpoint = "endpoint" in service
    has_host = "host" in service
    has_port = "port" in service
    location = f"services[{index}]"

    if has_endpoint:
        raise ConfigError(f"{location} already contains endpoint")
    if has_host != has_port:
        raise ConfigError(f"{location} must contain both host and port")
    if has_host:
        service["endpoint"] = f"{service.pop('host')}:{service.pop('port')}"

    # A service may itself contain unknown objects/arrays with more services.
    for key, child in service.items():
        if key != "services":
            _visit(child)


def transform(config: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(config, dict):
        raise ConfigError("configuration root must be an object")
    if config.get("schema") != 1:
        raise ConfigError("only schema=1 configurations can be migrated")
    result = deepcopy(config)
    _visit(result)
    result["schema"] = 2
    return result


migrate = transform
