import json

import pytest

from parser import parse


def test_empty_text_returns_empty_mapping():
    assert parse("") == {}


def test_parses_json_value_types():
    result = parse(
        'string="value"\n'
        'integer=42\n'
        'negative=-7\n'
        'boolean=true\n'
        'null=null\n'
        'array=[1, false, "x"]\n'
        'object={"nested": 1}'
    )

    assert result == {
        "string": "value",
        "integer": 42,
        "negative": -7,
        "boolean": True,
        "null": None,
        "array": [1, False, "x"],
        "object": {"nested": 1},
    }
    assert type(result["boolean"]) is bool
    assert type(result["integer"]) is int


def test_generated_json_values_keep_their_types_and_values():
    values = [
        0,
        -1,
        2**2048 + 1,
        True,
        False,
        None,
        "a=b\\n\\\"quoted\\\"",
        [0, True, None, {"x": -3}],
        {"empty": [], "unicode": "e\\u0301"},
    ]
    text = "\n".join(
        f"value{i}={json.dumps(value, ensure_ascii=False)}"
        for i, value in enumerate(values)
    )

    result = parse(text)

    assert list(result) == [f"value{i}" for i in range(len(values))]
    assert list(result.values()) == values
    assert type(result["value3"]) is bool
    assert type(result["value4"]) is bool
    assert type(result["value0"]) is int
    assert type(result["value2"]) is int


def test_integer_precision_is_preserved():
    value = 10**1000 + 123456789

    result = parse(f"large={value}")

    assert result["large"] == value
    assert type(result["large"]) is int


def test_first_equals_sign_separates_key_from_json_value():
    assert parse('key="left=right"') == {"key": "left=right"}


def test_keys_are_not_trimmed_or_unicode_normalized():
    composed = "é"
    decomposed = "e\u0301"

    result = parse(f" key ={json.dumps(composed)}\n{composed}=1\n{decomposed}=2")

    assert result[" key "] == "é"
    assert result[composed] == 1
    assert result[decomposed] == 2
    assert composed != decomposed
    assert len(result) == 3


def test_repeated_raw_key_is_rejected_even_when_values_match():
    with pytest.raises(ValueError) as caught:
        parse("same=1\nsame=1")

    assert str(caught.value) == "line 2"


@pytest.mark.parametrize(
    "text, line_number",
    [
        ("=1", 1),
        ("ok=1\nbad", 2),
        ("ok=1\nbad\nlast=2", 2),
        ("ok=1\nlast=", 2),
        ("ok=1\nlast={", 2),
        ("ok=1\nlast=NaN", 2),
    ],
)
def test_every_invalid_line_fails_with_exact_one_based_line_message(text, line_number):
    with pytest.raises(ValueError) as caught:
        parse(text)

    assert str(caught.value) == f"line {line_number}"


def test_distinct_keys_that_differ_only_by_whitespace_are_not_duplicates():
    assert parse("a=1\n a=2") == {"a": 1, " a": 2}
