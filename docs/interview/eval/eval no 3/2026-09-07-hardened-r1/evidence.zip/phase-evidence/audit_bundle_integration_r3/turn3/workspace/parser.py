"""Input parsing and deterministic business-event normalization."""
from datetime import datetime

_EVENT_FIELDS = ("tenant", "event_id", "revision", "user", "action", "time", "amount")
_POLICY_FIELDS = ("tenant", "user", "action", "start", "end", "decision")
_ACTIONS = frozenset(("read", "write", "delete", "export"))


def _text(value, name):
    if not isinstance(value, str) or not value:
        raise ValueError(name)
    return value


def _time(value, name):
    value = _text(value, name)
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (TypeError, ValueError):
        raise ValueError(name)
    if parsed.tzinfo is None:
        raise ValueError(name)
    return parsed


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(name)
    return value


def parse(data):
    """Validate without mutating *data*, and return a private normalized copy."""
    if not isinstance(data, dict) or set(("events", "policies")) - set(data):
        raise ValueError("input")
    events, policies = data["events"], data["policies"]
    if not isinstance(events, list) or not isinstance(policies, list):
        raise ValueError("input")

    normalized_events = []
    for source in events:
        if not isinstance(source, dict):
            raise ValueError("event")
        for field in _EVENT_FIELDS:
            if field not in source:
                raise ValueError(field)
        event = {field: source[field] for field in _EVENT_FIELDS}
        event["tenant"] = _text(event["tenant"], "tenant")
        event["event_id"] = _text(event["event_id"], "event_id")
        event["user"] = _text(event["user"], "user")
        if not isinstance(event["action"], str) or event["action"] not in _ACTIONS:
            raise ValueError("action")
        _integer(event["revision"], "revision")
        _integer(event["amount"], "amount")
        event["_time"] = _time(event["time"], "time")
        normalized_events.append(event)

    normalized_policies = []
    for source in policies:
        if not isinstance(source, dict):
            raise ValueError("policy")
        for field in _POLICY_FIELDS:
            if field not in source:
                raise ValueError(field)
        policy = {field: source[field] for field in _POLICY_FIELDS}
        for field in ("tenant", "user", "action"):
            _text(policy[field], field)
        if policy["user"] != "*" and not policy["user"]:
            raise ValueError("user")
        if policy["action"] != "*" and (not isinstance(policy["action"], str) or policy["action"] not in _ACTIONS):
            raise ValueError("action")
        if not isinstance(policy["decision"], str) or policy["decision"] not in ("allow", "deny"):
            raise ValueError("decision")
        policy["_start"] = _time(policy["start"], "start")
        policy["_end"] = _time(policy["end"], "end")
        if policy["_start"] > policy["_end"]:
            raise ValueError("range")
        normalized_policies.append(policy)
    return {"events": normalized_events, "policies": normalized_policies}


def deduplicate(events):
    """Idempotently remove equal formal events; conflicting duplicates fail as one batch."""
    found = {}
    for event in events:
        key = (event["tenant"], event["event_id"], event["revision"])
        formal = tuple(event[field] for field in _EVENT_FIELDS)
        previous = found.get(key)
        if previous is not None and previous[0] != formal:
            raise ValueError("conflict")
        if previous is None:
            found[key] = (formal, event)
    return [item[1] for item in found.values()]
