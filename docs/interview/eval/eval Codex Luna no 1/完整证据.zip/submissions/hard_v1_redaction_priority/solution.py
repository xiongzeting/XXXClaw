def solve(data):
    text = data["text"]
    rules = data["rules"]

    ordered_rules = []
    counts = {}
    seen = set()
    for rule in rules:
        literal = rule["literal"]
        if literal == "" or literal in seen:
            raise ValueError("literal must be non-empty and unique")
        seen.add(literal)
        counts[literal] = 0
        ordered_rules.append((literal, rule["replacement"]))

    protected = data.get("protected", [])
    for interval in protected:
        if (
            not isinstance(interval, (list, tuple))
            or len(interval) != 2
            or any(isinstance(endpoint, bool) or not isinstance(endpoint, int)
                   for endpoint in interval)
        ):
            raise ValueError("invalid protected interval")
        start, end = interval
        if start < 0 or start > end or end > len(text):
            raise ValueError("invalid protected interval")

    # Matching is a single pass over the original text.  Longer literals
    # have priority at each position; replacement text is never rescanned.
    ordered_rules.sort(key=lambda item: len(item[0]), reverse=True)
    pieces = []
    position = 0
    while position < len(text):
        match = None
        for literal, replacement in ordered_rules:
            end = position + len(literal)
            if end <= len(text) and text.startswith(literal, position):
                if not any(position < protected_end and protected_start < end
                           for protected_start, protected_end in protected):
                    match = (literal, replacement, end)
                    break
        if match is None:
            pieces.append(text[position])
            position += 1
        else:
            literal, replacement, position = match
            pieces.append(replacement)
            counts[literal] += 1

    return {"text": "".join(pieces), "counts": counts}
