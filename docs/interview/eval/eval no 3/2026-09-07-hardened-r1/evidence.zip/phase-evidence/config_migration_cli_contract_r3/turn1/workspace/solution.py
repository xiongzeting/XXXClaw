"""Public migration API."""
from package.transform import migrate


def solve(data):
    """Return a migrated copy of *data* without modifying the input."""
    return migrate(data)
