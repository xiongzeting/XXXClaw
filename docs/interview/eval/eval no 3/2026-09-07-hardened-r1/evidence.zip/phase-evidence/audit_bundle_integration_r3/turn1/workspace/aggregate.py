"""Stable aggregation of authorized, latest event revisions."""
from collections import defaultdict


def latest(events):
    selected = {}
    for event in events:
        key = (event["tenant"], event["event_id"])
        old = selected.get(key)
        if old is None or event["revision"] > old["revision"]:
            selected[key] = event
    return list(selected.values())


def aggregate(events):
    totals = defaultdict(lambda: [0, 0])
    for event in events:
        row = totals[(event["tenant"], event["user"])]
        row[0] += 1
        row[1] += event["amount"]
    return {
        "version": 1,
        "users": [
            {"tenant": tenant, "user": user, "count": values[0], "amount": values[1]}
            for (tenant, user), values in sorted(totals.items())
        ],
        "total_events": len(events),
    }
