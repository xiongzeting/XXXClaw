"""Batch adapter for the legacy response API."""

from api import respond


def respond_batch(data):
    if not isinstance(data, dict) or "items" not in data:
        raise ValueError("batch data must contain items")
    items = data["items"]
    if not isinstance(items, list):
        raise ValueError("items must be a list")
    return [respond(item) for item in items]
