#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path
import sys
import tempfile


def load_items():
    with (Path(__file__).resolve().parent / "data.json").open(encoding="utf-8") as f:
        data = json.load(f)
    return {item["id"]: item["value"] for item in data["items"]}


def atomic_write(path, content):
    destination = Path(path)
    temporary = None
    try:
        fd, temporary = tempfile.mkstemp(
            dir=str(destination.parent), prefix=f".{destination.name}.", suffix=".tmp"
        )
        with os.fdopen(fd, "wb") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary, destination)
        temporary = None
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("id")
    parser.add_argument("--format", choices=("text", "json"), default="text")
    parser.add_argument("--batch", action="store_true")
    parser.add_argument("--output")
    args = parser.parse_args()

    if args.batch:
        ids = args.id.split(",")
        if any(item == "" for item in ids):
            return 2
    else:
        ids = [args.id]

    items = load_items()
    missing = [item for item in ids if item not in items]

    if args.format == "json":
        if args.batch:
            records = [
                {"id": item, "value": items[item]}
                if item in items
                else {"error": "missing", "id": item}
                for item in ids
            ]
            output = json.dumps(records, separators=(",", ":")) + "\n"
        elif missing:
            output = json.dumps(
                {"error": "missing", "id": args.id}, separators=(",", ":")
            ) + "\n"
        else:
            output = json.dumps(
                {"id": args.id, "value": items[args.id]}, separators=(",", ":")
            ) + "\n"
        error_output = ""
    else:
        output = "".join(f"{item}={items[item]}\n" for item in ids if item in items)
        error_output = "".join(f"missing: {item}\n" for item in missing)

    status = 1 if missing else 0
    if args.output and status == 0:
        atomic_write(args.output, output.encode("utf-8"))
        output = ""

    sys.stdout.write(output)
    sys.stderr.write(error_output)
    return status


if __name__ == "__main__":
    raise SystemExit(main())
