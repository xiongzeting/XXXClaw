import json
import sys

from solution import solve


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 2:
        return 2

    input_path, output_path = argv
    try:
        with open(input_path, "r", encoding="utf-8") as input_file:
            data = json.load(input_file)
        result = solve(data)
        output = json.dumps(result, ensure_ascii=False, separators=(",", ":"))
    except (json.JSONDecodeError, UnicodeDecodeError, ValueError):
        return 1

    with open(output_path, "w", encoding="utf-8", newline="") as output_file:
        output_file.write(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
