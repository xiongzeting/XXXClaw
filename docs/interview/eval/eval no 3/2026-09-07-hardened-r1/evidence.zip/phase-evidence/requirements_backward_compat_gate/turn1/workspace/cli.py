# Implement CLI contract.
