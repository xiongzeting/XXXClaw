"""Schema migration and validation primitives."""
import copy


def _port(value):
    if type(value) is not int or not 1 <= value <= 65535:
        raise ValueError("port")
    return value


def _endpoint(value):
    if not isinstance(value, str) or not value:
        raise ValueError("endpoint")
    return value


def _profiles(data):
    profiles = data.get("profiles", {})
    if profiles is None:
        return {}
    if not isinstance(profiles, dict):
        raise ValueError("profiles")
    resolved = {}

    def get(name, chain=()):
        if not isinstance(name, str) or name not in profiles or name in chain:
            raise ValueError("profile")
        if name in resolved:
            return copy.deepcopy(resolved[name])
        row = profiles[name]
        if not isinstance(row, dict):
            raise ValueError("profile")
        base = get(row["extends"], chain + (name,)) if "extends" in row else {}
        base.update({k: copy.deepcopy(v) for k, v in row.items() if k != "extends"})
        resolved[name] = base
        return copy.deepcopy(base)

    for name in profiles:
        get(name)
    return get


def migrate(data):
    if not isinstance(data, dict):
        raise ValueError("document")
    if data.get("schema") not in (1, 2):
        raise ValueError("schema")
    source = copy.deepcopy(data)
    profile = _profiles(source)

    def service(item):
        if not isinstance(item, dict):
            raise ValueError("service")
        merged = {}
        if "profile" in item:
            merged.update(profile(item["profile"]))
        for key, value in item.items():
            if key not in ("profile", "override"):
                merged[key] = copy.deepcopy(value)
        if "override" in item:
            override = item["override"]
            if not isinstance(override, dict):
                raise ValueError("override")
            merged.update(copy.deepcopy(override))
        convert_endpoint(merged)
        return walk(merged)

    def walk(node):
        if isinstance(node, list):
            return [walk(value) for value in node]
        if not isinstance(node, dict):
            return node
        result = {}
        for key, value in node.items():
            if key == "services":
                if not isinstance(value, list):
                    raise ValueError("services")
                result[key] = [service(item) for item in value]
            elif key == "profiles":
                result[key] = copy.deepcopy(value)
            else:
                result[key] = walk(value)
        return result

    def convert_endpoint(item):
        has_host = "host" in item
        has_port = "port" in item
        if has_host or has_port:
            if "endpoint" in item:
                raise ValueError("endpoint conflict")
            if not has_host or not has_port:
                raise ValueError("host/port")
            host = item["host"]
            if not isinstance(host, str) or not host:
                raise ValueError("host")
            port = _port(item["port"])
            item["endpoint"] = f"{host}:{port}"
            del item["host"]
            del item["port"]
        else:
            _endpoint(item.get("endpoint"))

    result = walk(source)
    result["schema"] = 2
    return result

# Kept as a short parser-facing alias for callers of the package module.
parse_and_migrate = migrate
