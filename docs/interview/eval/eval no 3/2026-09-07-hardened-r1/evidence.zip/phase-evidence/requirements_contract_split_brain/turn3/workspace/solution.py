"""Versioned public business API."""

_KINDS = frozenset(("ok", "missing", "invalid", "conflict"))
_STATUSES = {"ok": 200, "missing": 404, "invalid": 400, "conflict": 409}
_V1_ERRORS = {"missing": 1, "invalid": 2, "conflict": 3}
_V2_ERRORS = {"missing": "E_MISSING", "invalid": "E_INVALID", "conflict": "E_CONFLICT"}
_VERSIONS = (1, 2)


def _version(value):
    # bool is an int subclass, but is not a protocol version.
    return value if isinstance(value, int) and not isinstance(value, bool) else None


def _version_error():
    return {"status": 400, "body": {"error": "E_VERSION"}}


def _respond_request(request, inherited_version=1):
    if not isinstance(request, dict):
        raise ValueError("request must be an object")

    version = request.get("version", inherited_version)
    if version not in _VERSIONS:
        return _version_error()

    kind = request.get("kind", "ok")
    if not isinstance(kind, str) or kind not in _KINDS:
        kind = "invalid"

    if kind == "ok":
        body = {"ok": True, "error": None}
    else:
        errors = _V1_ERRORS if version == 1 else _V2_ERRORS
        body = {"ok": False, "error": errors[kind]}
    return {"status": _STATUSES[kind], "body": body}


def solve(data):
    """Solve one request or a versioned batch without mutating ``data``."""
    if not isinstance(data, dict):
        raise ValueError("data must be an object")

    if "items" in data:
        items = data["items"]
        if not isinstance(items, list):
            raise ValueError("items must be a list")
        inherited = data.get("version", 1)
        if inherited not in _VERSIONS:
            return [_version_error() for _ in items]
        return [_respond_request(item, inherited) for item in items]

    return _respond_request(data, 1)


protocol = solve

__all__ = ["solve", "protocol"]
