"""Audit pipeline facade."""
from parser import deduplicate, parse
from policy import authorize_all
from aggregate import aggregate, latest


def audit(data):
    parsed = parse(data)
    # Conflict detection and deduplication happen before any policy decision.
    unique = deduplicate(parsed["events"])
    selected = latest(unique)
    authorize_all(selected, parsed["policies"])
    return aggregate(selected)
