"""Version-aware batch response adapter."""

from solution import solve


def respond_batch(data):
    if not isinstance(data, dict) or "items" not in data:
        raise ValueError("batch data must contain items")
    return solve(data)
