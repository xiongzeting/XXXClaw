import copy
import json
import os
from pathlib import Path


def load(root, name, default):
    path = Path(root) / name
    if not path.exists():
        return copy.deepcopy(default)
    return json.loads(path.read_text('utf-8'))


def save(root, name, data, fault=None, point=None):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    if fault is not None and point is not None:
        before_points = {point.replace('_after_commit', '_before_commit')}
        if point.startswith('orders_'):
            before_points.add('before_orders')
        elif point.startswith('billing_'):
            before_points.add('before_billing')
        elif point.startswith('inventory_'):
            before_points.add('before_inventory')
        elif point.startswith('refund_'):
            before_points.add('before_refund')
        if fault in before_points:
            raise RuntimeError(fault)
    path = root / name
    temp = root / ('.' + name + '.tmp')
    temp.write_text(json.dumps(data, sort_keys=True, ensure_ascii=False), 'utf-8')
    os.replace(temp, path)
    if fault is not None and fault == point:
        raise RuntimeError(point)


def service_op(root, service, key, amount, fault=None):
    state = load(root, service + '.json', {})
    if key in state:
        if state[key] != amount:
            raise ValueError('payload conflict')
        return state[key]
    state[key] = amount
    save(root, service + '.json', state, fault, service + '_after_commit')
    return amount


def gateway(root, request, fault=None):
    if type(request['cents']) is not int or request['cents'] <= 0:
        raise ValueError('cents')
    inventory_result = request['inventory_result']
    if inventory_result not in ('success', 'temporary', 'permanent'):
        raise ValueError('inventory_result')

    identity = json.dumps([request['tenant'], request['order_id']])
    payload = {key: request[key] for key in ('tenant', 'order_id', 'cents', 'sku')}
    orders = load(root, 'orders.json', {})
    existing = orders.get(identity)
    if existing is not None:
        if existing.get('payload') != payload:
            raise ValueError('payload conflict')
        if existing.get('status') in ('completed', 'compensated'):
            return existing['status']
    else:
        orders[identity] = {'payload': payload, 'status': 'pending'}
        save(root, 'orders.json', orders, fault, 'orders_after_commit')

    service_op(root, 'billing', identity, request['cents'], fault)

    if inventory_result == 'temporary':
        raise RuntimeError('inventory temporary')

    if inventory_result == 'permanent':
        service_op(root, 'refund', identity, request['cents'], fault)
        status = 'compensated'
    else:
        service_op(root, 'inventory', identity, 1, fault)
        status = 'completed'

    orders = load(root, 'orders.json', {})
    if orders[identity]['payload'] != payload:
        raise ValueError('payload conflict')
    orders[identity]['status'] = status
    save(root, 'orders.json', orders, fault, 'orders_after_commit')
    return status


execute = gateway
