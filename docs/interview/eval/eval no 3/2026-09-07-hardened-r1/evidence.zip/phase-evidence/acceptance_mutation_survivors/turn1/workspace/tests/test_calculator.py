from calculator import solve


def test_single_unit_and_non_exempt_tax():
    assert solve({"lines": [{"id": "a", "units": 1, "exempt": False}]}) == {
        "lines": [
            {"id": "a", "base_cents": 100, "tax_cents": 7, "total_cents": 107}
        ],
        "grand_total_cents": 107,
    }


def test_progressive_unit_price_boundaries():
    assert solve(
        {
            "lines": [
                {"id": "twenty_one", "units": 21, "exempt": False},
                {"id": "twenty", "units": 20, "exempt": False},
                {"id": "ten", "units": 10, "exempt": False},
                {"id": "zero", "units": 0, "exempt": False},
            ]
        }
    ) == {
        "lines": [
            {"id": "ten", "base_cents": 1000, "tax_cents": 70, "total_cents": 1070},
            {"id": "twenty", "base_cents": 1800, "tax_cents": 126, "total_cents": 1926},
            {"id": "twenty_one", "base_cents": 1850, "tax_cents": 130, "total_cents": 1980},
            {"id": "zero", "base_cents": 0, "tax_cents": 0, "total_cents": 0},
        ],
        "grand_total_cents": 4976,
    }


def test_discount_is_applied_in_id_order_and_can_cross_line_boundaries():
    # Input order is deliberately different from the required ascending id order.
    assert solve(
        {
            "discount_cents": 1150,
            "lines": [
                {"id": "c", "units": 1, "exempt": False},
                {"id": "a", "units": 10, "exempt": False},
                {"id": "b", "units": 2, "exempt": True},
            ],
        }
    ) == {
        "lines": [
            {"id": "a", "base_cents": 0, "tax_cents": 0, "total_cents": 0},
            {"id": "b", "base_cents": 50, "tax_cents": 0, "total_cents": 50},
            {"id": "c", "base_cents": 100, "tax_cents": 7, "total_cents": 107},
        ],
        "grand_total_cents": 157,
    }


def test_discount_larger_than_bill_never_creates_negative_amounts():
    assert solve(
        {
            "discount_cents": 9999,
            "lines": [{"id": "a", "units": 21, "exempt": False}],
        }
    ) == {
        "lines": [{"id": "a", "base_cents": 0, "tax_cents": 0, "total_cents": 0}],
        "grand_total_cents": 0,
    }


def test_tax_rounds_each_line_half_cent_up_and_exempt_lines_are_zero_tax():
    assert solve(
        {
            "lines": [
                # 1 cent of tax rounds from 0.07 cents to 1 cent.
                {"id": "round_up", "units": 0, "exempt": False},
                {"id": "taxed", "units": 1, "exempt": False},
                {"id": "exempt", "units": 1, "exempt": True},
            ]
        }
    ) == {
        "lines": [
            {"id": "exempt", "base_cents": 100, "tax_cents": 0, "total_cents": 100},
            {"id": "round_up", "base_cents": 0, "tax_cents": 0, "total_cents": 0},
            {"id": "taxed", "base_cents": 100, "tax_cents": 7, "total_cents": 107},
        ],
        "grand_total_cents": 207,
    }


def test_half_cent_tax_rounding_at_a_nontrivial_base():
    # 50 cents * 7% = 3.5 cents, so this must round up to 4 cents.
    # The 50-cent base is reached by discounting half of a 100-cent unit.
    assert solve(
        {
            "discount_cents": 50,
            "lines": [{"id": "a", "units": 1, "exempt": False}],
        }
    ) == {
        "lines": [{"id": "a", "base_cents": 50, "tax_cents": 4, "total_cents": 54}],
        "grand_total_cents": 54,
    }


def test_default_zero_discount_and_grand_total_are_exact():
    result = solve(
        {
            "lines": [
                {"id": "b", "units": 2, "exempt": True},
                {"id": "a", "units": 11, "exempt": False},
            ]
        }
    )
    assert result == {
        "lines": [
            {"id": "a", "base_cents": 1080, "tax_cents": 76, "total_cents": 1156},
            {"id": "b", "base_cents": 200, "tax_cents": 0, "total_cents": 200},
        ],
        "grand_total_cents": 1356,
    }
