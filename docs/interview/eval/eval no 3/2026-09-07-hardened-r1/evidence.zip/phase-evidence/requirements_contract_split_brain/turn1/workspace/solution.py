"""Public business API."""

_KINDS = frozenset(("ok", "missing", "invalid", "conflict"))
_STATUSES = {"ok": 200, "missing": 404, "invalid": 400, "conflict": 409}
_ERRORS = {"missing": 1, "invalid": 2, "conflict": 3}


def solve(data):
    """Solve one business request without changing *data*.

    The public API deliberately accepts only a single mapping.  Protocol
    adapters (such as the batch adapter) are kept outside this function.
    """
    if not isinstance(data, dict):
        raise ValueError("data must be an object")

    kind = data.get("kind", "ok")
    if not isinstance(kind, str) or kind not in _KINDS:
        raise ValueError("invalid kind")

    if kind == "ok":
        return {"status": 200, "body": {"ok": True, "error": None}}
    return {
        "status": _STATUSES[kind],
        "body": {"ok": False, "error": _ERRORS[kind]},
    }


# Keep the original public name used by the smoke test and callers.
protocol = solve

__all__ = ["solve", "protocol"]
