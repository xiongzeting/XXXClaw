import math


# The published tariff is based on one-kilogram (or part thereof) bands.
_ZONE_BASE = {
    "local": 500,
    "regional": 700,
    "national": 900,
}
_BAND_PRICE = 200
_FRAGILE_SURCHARGE = 150


def _true_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def solve(data):
    """Calculate shipping charges without modifying *data*."""
    if not isinstance(data, dict):
        raise ValueError("data must be an object")

    packages = data.get("packages", [])
    if not isinstance(packages, list):
        raise ValueError("packages must be a list")

    free_ids = data.get("free_ids", [])
    if not isinstance(free_ids, list):
        raise ValueError("free_ids must be a list")

    cap = data.get("cap_cents", None)
    if cap is not None and (not _true_int(cap) or cap < 0):
        raise ValueError("cap_cents must be a non-negative integer or null")

    seen = set()
    charges = []
    for package in packages:
        if not isinstance(package, dict):
            raise ValueError("package must be an object")
        package_id = package.get("id")
        if not isinstance(package_id, str):
            raise ValueError("id must be a string")
        if package_id in seen:
            raise ValueError("duplicate id")
        seen.add(package_id)

        weight = package.get("weight_g")
        if not _true_int(weight) or weight <= 0:
            raise ValueError("weight_g must be a positive integer")
        zone = package.get("zone")
        if zone not in _ZONE_BASE:
            raise ValueError("unknown zone")

        amount = _ZONE_BASE[zone] + max(0, math.ceil(weight / 1000) - 1) * _BAND_PRICE
        if package.get("fragile"):
            amount += _FRAGILE_SURCHARGE
        if package_id in free_ids:
            amount = 0
        charges.append({"id": package_id, "shipping_cents": amount})

    if cap is not None:
        remaining = cap
        by_id = sorted(charges, key=lambda item: item["id"])
        for item in by_id:
            kept = min(item["shipping_cents"], remaining)
            item["shipping_cents"] = kept
            remaining -= kept

    # Preserve package order in the result; id order is used only for cap allocation.
    by_id = {item["id"]: item for item in charges}
    return [by_id[package["id"]].copy() for package in packages]
