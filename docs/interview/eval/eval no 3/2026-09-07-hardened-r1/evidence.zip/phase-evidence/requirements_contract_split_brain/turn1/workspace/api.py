"""Version-one response adapter."""

from solution import solve


def respond(item):
    """Respond to a legacy (unversioned, v1) request."""
    return solve(item)
