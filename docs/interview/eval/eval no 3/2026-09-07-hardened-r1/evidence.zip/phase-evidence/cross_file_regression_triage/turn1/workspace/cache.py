"""Small process-local cache; solve never relies on mutable cached input."""
CACHE = {}


def lookup(key):
    return CACHE.get(key)


def put(key, value):
    CACHE[key] = value
    return value
