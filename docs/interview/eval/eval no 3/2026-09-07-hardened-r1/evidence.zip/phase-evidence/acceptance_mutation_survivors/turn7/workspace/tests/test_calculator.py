from calculator import solve


def test_single_unit_and_non_exempt_tax():
    assert solve({"lines": [{"id": "a", "units": 1, "exempt": False}]}) == {
        "lines": [
            {"id": "a", "base_cents": 100, "tax_cents": 7, "total_cents": 107}
        ],
        "grand_total_cents": 107,
    }


def test_progressive_unit_price_boundaries():
    assert solve(
        {
            "lines": [
                {"id": "twenty_one", "units": 21, "exempt": False},
                {"id": "twenty", "units": 20, "exempt": False},
                {"id": "ten", "units": 10, "exempt": False},
                {"id": "zero", "units": 0, "exempt": False},
            ]
        }
    ) == {
        "lines": [
            {"id": "ten", "base_cents": 1000, "tax_cents": 70, "total_cents": 1070},
            {"id": "twenty", "base_cents": 1800, "tax_cents": 126, "total_cents": 1926},
            {"id": "twenty_one", "base_cents": 1850, "tax_cents": 130, "total_cents": 1980},
            {"id": "zero", "base_cents": 0, "tax_cents": 0, "total_cents": 0},
        ],
        "grand_total_cents": 4976,
    }


def test_discount_is_applied_in_id_order_and_can_cross_line_boundaries():
    # Input order is deliberately different from the required ascending id order.
    assert solve(
        {
            "discount_cents": 1150,
            "lines": [
                {"id": "c", "units": 1, "exempt": False},
                {"id": "a", "units": 10, "exempt": False},
                {"id": "b", "units": 2, "exempt": True},
            ],
        }
    ) == {
        "lines": [
            {"id": "a", "base_cents": 0, "tax_cents": 0, "total_cents": 0},
            {"id": "b", "base_cents": 50, "tax_cents": 0, "total_cents": 50},
            {"id": "c", "base_cents": 100, "tax_cents": 7, "total_cents": 107},
        ],
        "grand_total_cents": 157,
    }


def test_discount_larger_than_bill_never_creates_negative_amounts():
    assert solve(
        {
            "discount_cents": 9999,
            "lines": [{"id": "a", "units": 21, "exempt": False}],
        }
    ) == {
        "lines": [{"id": "a", "base_cents": 0, "tax_cents": 0, "total_cents": 0}],
        "grand_total_cents": 0,
    }


def test_tax_rounds_each_line_half_cent_up_and_exempt_lines_are_zero_tax():
    assert solve(
        {
            "lines": [
                # 1 cent of tax rounds from 0.07 cents to 1 cent.
                {"id": "round_up", "units": 0, "exempt": False},
                {"id": "taxed", "units": 1, "exempt": False},
                {"id": "exempt", "units": 1, "exempt": True},
            ]
        }
    ) == {
        "lines": [
            {"id": "exempt", "base_cents": 100, "tax_cents": 0, "total_cents": 100},
            {"id": "round_up", "base_cents": 0, "tax_cents": 0, "total_cents": 0},
            {"id": "taxed", "base_cents": 100, "tax_cents": 7, "total_cents": 107},
        ],
        "grand_total_cents": 207,
    }


def test_half_cent_tax_rounding_at_a_nontrivial_base():
    # 50 cents * 7% = 3.5 cents, so this must round up to 4 cents.
    # The 50-cent base is reached by discounting half of a 100-cent unit.
    assert solve(
        {
            "discount_cents": 50,
            "lines": [{"id": "a", "units": 1, "exempt": False}],
        }
    ) == {
        "lines": [{"id": "a", "base_cents": 50, "tax_cents": 4, "total_cents": 54}],
        "grand_total_cents": 54,
    }


def test_default_zero_discount_and_grand_total_are_exact():
    result = solve(
        {
            "lines": [
                {"id": "b", "units": 2, "exempt": True},
                {"id": "a", "units": 11, "exempt": False},
            ]
        }
    )
    assert result == {
        "lines": [
            {"id": "a", "base_cents": 1080, "tax_cents": 76, "total_cents": 1156},
            {"id": "b", "base_cents": 200, "tax_cents": 0, "total_cents": 200},
        ],
        "grand_total_cents": 1356,
    }




def test_repeated_execution_does_not_accumulate_refund_state():
    data = {
        "lines": [{"id": "a", "units": 1, "exempt": False}],
        "refunds": [
            {"refund_id": "r1", "line_id": "a", "cents": 40},
            {"refund_id": "r1", "line_id": "a", "cents": 40},
        ],
    }
    first = solve(data)
    second = solve(data)
    assert first == second == {
        "lines": [{"id": "a", "base_cents": 100, "tax_cents": 7, "total_cents": 107}],
        "grand_total_cents": 107,
        "refunded_cents": 40,
        "net_cents": 67,
    }


def test_invalid_refund_line_is_rejected():
    try:
        solve(
            {
                "lines": [{"id": "a", "units": 1, "exempt": False}],
                "refunds": [{"refund_id": "r", "line_id": "missing", "cents": 1}],
            }
        )
    except ValueError:
        pass
    else:
        raise AssertionError("refund for an unknown line must raise ValueError")


def test_discount_tax_and_refund_rules_apply_together():
    assert solve(
        {
            "discount_cents": 50,
            "lines": [
                {"id": "b", "units": 1, "exempt": True},
                {"id": "a", "units": 1, "exempt": False},
            ],
            "refunds": [
                {"refund_id": "taxed-refund", "line_id": "a", "cents": 54},
                {"refund_id": "taxed-refund", "line_id": "a", "cents": 54},
                {"refund_id": "exempt-refund", "line_id": "b", "cents": 25},
            ],
        }
    ) == {
        "lines": [
            {"id": "a", "base_cents": 50, "tax_cents": 4, "total_cents": 54},
            {"id": "b", "base_cents": 100, "tax_cents": 0, "total_cents": 100},
        ],
        "grand_total_cents": 154,
        "refunded_cents": 79,
        "net_cents": 75,
    }


def test_refund_conflict_is_rejected_even_after_a_valid_replay():
    try:
        solve(
            {
                "lines": [{"id": "a", "units": 1, "exempt": False}],
                "refunds": [
                    {"refund_id": "r", "line_id": "a", "cents": 10},
                    {"refund_id": "r", "line_id": "a", "cents": 10},
                    {"refund_id": "r", "line_id": "a", "cents": 11},
                ],
            }
        )
    except ValueError:
        pass
    else:
        raise AssertionError("conflicting replay must raise ValueError")

    assert solve(
        {
            "lines": [
                {"id": "taxed", "units": 1, "exempt": False},
                {"id": "exempt", "units": 2, "exempt": True},
            ],
            "refunds": [
                {"refund_id": "r-tax", "line_id": "taxed", "cents": 50},
                {"refund_id": "r-exempt", "line_id": "exempt", "cents": 75},
            ],
        }
    ) == {
        "lines": [
            {"id": "exempt", "base_cents": 200, "tax_cents": 0, "total_cents": 200},
            {"id": "taxed", "base_cents": 100, "tax_cents": 7, "total_cents": 107},
        ],
        "grand_total_cents": 307,
        "refunded_cents": 125,
        "net_cents": 182,
    }


def test_same_refund_payload_is_idempotent_but_conflicting_payload_fails():
    refund = {"refund_id": "r1", "line_id": "a", "cents": 40}
    data = {
        "lines": [{"id": "a", "units": 1, "exempt": False}],
        "refunds": [refund, dict(refund)],
    }
    result = solve(data)
    assert result["refunded_cents"] == 40
    assert result["net_cents"] == 67

    conflicting = dict(data)
    conflicting["refunds"] = [refund, {"refund_id": "r1", "line_id": "a", "cents": 41}]
    try:
        solve(conflicting)
    except ValueError:
        pass
    else:
        raise AssertionError("conflicting refund replay must raise ValueError")


def test_refunds_cannot_exceed_cumulative_paid_amount_across_refund_ids():
    data = {
        "lines": [{"id": "a", "units": 1, "exempt": False}],
        "refunds": [
            {"refund_id": "r1", "line_id": "a", "cents": 60},
            {"refund_id": "r2", "line_id": "a", "cents": 47},
        ],
    }
    result = solve(data)
    assert result["refunded_cents"] == 107
    assert result["net_cents"] == 0

    over = dict(data)
    over["refunds"] = data["refunds"] + [
        {"refund_id": "r3", "line_id": "a", "cents": 1}
    ]
    try:
        solve(over)
    except ValueError:
        pass
    else:
        raise AssertionError("cumulative over-refund must raise ValueError")


def test_refund_uses_discounted_line_amount_without_redistributing_discount():
    base = {
        "discount_cents": 100,
        "lines": [
            {"id": "b", "units": 1, "exempt": False},
            {"id": "a", "units": 1, "exempt": False},
        ],
    }
    try:
        solve(
            dict(
                base,
                refunds=[{"refund_id": "r-a", "line_id": "a", "cents": 1}],
            )
        )
    except ValueError:
        pass
    else:
        raise AssertionError("a fully discounted line has no refundable amount")

    base["refunds"] = [{"refund_id": "r-b", "line_id": "b", "cents": 1}]
    assert solve(base) == {
        "lines": [
            {"id": "a", "base_cents": 0, "tax_cents": 0, "total_cents": 0},
            {"id": "b", "base_cents": 100, "tax_cents": 7, "total_cents": 107},
        ],
        "grand_total_cents": 107,
        "refunded_cents": 1,
        "net_cents": 106,
    }


def test_refund_cents_must_be_a_positive_integer():
    for cents in (0, -1, True, 1.5):
        try:
            solve(
                {
                    "lines": [{"id": "a", "units": 1, "exempt": False}],
                    "refunds": [{"refund_id": "r", "line_id": "a", "cents": cents}],
                }
            )
        except ValueError:
            continue
        raise AssertionError("non-positive or non-integer refund must raise ValueError")
