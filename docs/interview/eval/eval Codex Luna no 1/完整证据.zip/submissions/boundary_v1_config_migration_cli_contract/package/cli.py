from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .parser import ConfigError
from .storage import load, save
from .transform import transform


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Migrate a schema=1 service configuration")
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path, nargs="?")
    args = parser.parse_args(argv)
    output = args.output or args.input
    try:
        save(transform(load(args.input)), output)
    except (ConfigError, OSError, TypeError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0
