from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


def timezone(name):
    if type(name) is not str or not name:
        raise ValueError("invalid timezone")
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError) as exc:
        raise ValueError("invalid timezone") from exc


def parsed(text):
    if type(text) is not str:
        raise ValueError("invalid timestamp")
    try:
        value = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError("invalid timestamp") from exc
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("timestamp requires offset")
    return value


def local_day(text, zone):
    return parsed(text).astimezone(zone).date().isoformat()


def date_text(text, name="date"):
    if type(text) is not str:
        raise ValueError(f"invalid {name}")
    try:
        value = datetime.strptime(text, "%Y-%m-%d")
    except ValueError as exc:
        raise ValueError(f"invalid {name}") from exc
    return value.date().isoformat()
