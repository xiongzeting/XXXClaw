import json
import os
import sys
import tempfile
from pathlib import Path

from solution import solve


def main():
    if len(sys.argv) != 3:
        return 2

    input_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    temporary_path = None
    try:
        data = json.loads(input_path.read_text(encoding="utf-8"))
        result = solve(data)
        payload = json.dumps(
            result,
            ensure_ascii=False,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")

        # Create the temporary file beside the destination, then replace it only
        # after all parsing and calculation have completed.
        fd, temporary_path = tempfile.mkstemp(
            prefix=".cli-", suffix=".tmp", dir=str(output_path.parent)
        )
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_path, output_path)
        temporary_path = None
        return 0
    except (ValueError, OSError, TypeError):
        return 1
    finally:
        if temporary_path is not None:
            try:
                os.unlink(temporary_path)
            except OSError:
                pass


if __name__ == "__main__":
    sys.exit(main())
