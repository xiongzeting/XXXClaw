import json
import os
import sys
import tempfile

from solution import solve


def main():
    if len(sys.argv) != 3:
        return 2

    input_path, output_path = sys.argv[1:]
    try:
        with open(input_path, "r", encoding="utf-8") as input_file:
            data = json.load(input_file)
        result = solve(data)
    except (OSError, json.JSONDecodeError, ValueError):
        return 1

    output_dir = os.path.dirname(os.path.abspath(output_path)) or "."
    temp_path = None
    try:
        fd, temp_path = tempfile.mkstemp(prefix=".invoice-", dir=output_dir)
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as output_file:
            json.dump(result, output_file, ensure_ascii=False, separators=(",", ":"))
        os.replace(temp_path, output_path)
    except OSError:
        if temp_path is not None:
            try:
                os.unlink(temp_path)
            except OSError:
                pass
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
