import copy
import math

from aggregate import total
from dedup import latest
from filters import in_window
from loader import list_value, object_value, text_value
from timestamps import date_text, local_day, timezone


def _integer(value, name, minimum=None):
    if type(value) is not int or (minimum is not None and value < minimum):
        raise ValueError(f"invalid {name}")
    return value


def _validate(data):
    root = object_value(data, "data")
    timezones = object_value(root.get("timezones"), "timezones")
    events = list_value(root.get("events"), "events")
    queries = list_value(root.get("queries"), "queries")
    zones = {}
    for tenant, name in timezones.items():
        text_value(tenant, "tenant")
        zones[tenant] = timezone(name)
    event_rows = []
    for event in events:
        row = object_value(event, "event")
        for key in ("tenant", "id", "time"):
            text_value(row.get(key), f"event.{key}")
        _integer(row.get("revision"), "event.revision", 0)
        if (type(row.get("amount")) not in (int, float) or
                type(row.get("amount")) is bool or
                (isinstance(row.get("amount"), float) and not math.isfinite(row["amount"]))):
            raise ValueError("invalid event.amount")
        if row["tenant"] not in zones:
            raise ValueError("unknown event tenant")
        event_rows.append(row)
    query_rows = []
    for query in queries:
        row = object_value(query, "query")
        for key in ("query_id", "tenant", "start", "end"):
            text_value(row.get(key), f"query.{key}")
        if row["tenant"] not in zones:
            raise ValueError("unknown query tenant")
        start = date_text(row["start"], "query.start")
        end = date_text(row["end"], "query.end")
        if start > end:
            raise ValueError("query start after end")
        query_rows.append(row)
    return zones, event_rows, query_rows


def solve(data):
    zones, events, queries = _validate(data)
    selected = latest(events)
    output = []
    for query in queries:
        grouped = {}
        for event in selected:
            if event["tenant"] != query["tenant"]:
                continue
            day = local_day(event["time"], zones[event["tenant"]])
            if in_window(day, query["start"], query["end"]):
                grouped.setdefault(day, []).append(event)
        days = []
        for day in sorted(grouped):
            rows = grouped[day]
            days.append({"date": day, "ids": sorted(row["id"] for row in rows), "total": total(rows)})
        output.append({"query_id": query["query_id"], "days": days})
    return copy.deepcopy(output)


report = solve
