"""Build and verify recursive Python-file manifests."""

from __future__ import annotations

import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path, PurePosixPath
from typing import Dict, Iterable


def _excluded(name: str) -> bool:
    return name.startswith(".") or name == "__pycache__"


def _source_files(source_dir: Path) -> Iterable[tuple[str, Path]]:
    """Yield non-symlink .py files as POSIX relative paths, in sorted order."""
    if source_dir.is_symlink() or not source_dir.is_dir():
        raise ValueError("source directory is not a real directory")

    found: list[tuple[str, Path]] = []

    def walk(directory: Path, relative_parts: tuple[str, ...]) -> None:
        try:
            entries = list(os.scandir(directory))
        except OSError as exc:
            raise ValueError(f"cannot read source directory: {directory}") from exc

        for entry in entries:
            name = entry.name
            if _excluded(name) or entry.is_symlink():
                continue
            child = directory / name
            parts = relative_parts + (name,)
            try:
                if entry.is_dir(follow_symlinks=False):
                    walk(child, parts)
                elif entry.is_file(follow_symlinks=False) and name.endswith(".py"):
                    found.append(("/".join(parts), child))
            except OSError as exc:
                raise ValueError(f"cannot inspect source entry: {child}") from exc

    walk(source_dir, ())
    yield from sorted(found, key=lambda item: item[0])


def _digest(path: Path) -> str:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
    except OSError as exc:
        raise ValueError(f"cannot read source file: {path}") from exc
    return digest.hexdigest()


def _manifest(source_dir: Path) -> Dict[str, str]:
    return {relative: _digest(path) for relative, path in _source_files(source_dir)}


def _safe_manifest_path(value: object) -> bool:
    if not isinstance(value, str) or not value or "\\" in value:
        return False
    path = PurePosixPath(value)
    return (
        not path.is_absolute()
        and ".." not in path.parts
        and "." not in path.parts
        and not any(_excluded(part) for part in path.parts)
        and value.endswith(".py")
    )


def _read_manifest(out_file: Path) -> dict[str, str] | None:
    try:
        if out_file.is_symlink() or not out_file.is_file():
            return None
        with out_file.open("r", encoding="utf-8") as stream:
            value = json.load(stream)
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    if not isinstance(value, dict):
        return None
    if any(not _safe_manifest_path(key) for key in value):
        return None
    if any(
        not isinstance(digest, str)
        or len(digest) != hashlib.sha256().digest_size * 2
        or any(char not in "0123456789abcdef" for char in digest)
        for digest in value.values()
    ):
        return None
    return value


def _write_manifest_atomic(output: Path, manifest: Dict[str, str]) -> None:
    if output.is_symlink():
        raise ValueError("manifest output must not be a symbolic link")
    temporary: Path | None = None
    try:
        output.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary_name = tempfile.mkstemp(prefix=f".{output.name}.", suffix=".tmp", dir=str(output.parent))
        temporary = Path(temporary_name)
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(manifest, stream, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, output)
        temporary = None
    except (OSError, TypeError, ValueError) as exc:
        raise ValueError(f"cannot atomically write manifest: {output}") from exc
    finally:
        if temporary is not None:
            try:
                temporary.unlink()
            except OSError:
                pass


def build_manifest(source_dir, out_file):
    """Rebuild and atomically replace the manifest for the current source tree."""
    source = Path(source_dir)
    output = Path(out_file)
    # Complete traversal and hashing happens before touching the old manifest.
    manifest = _manifest(source)
    _write_manifest_atomic(output, manifest)


def update_manifest(source_dir, out_file):
    """Update the manifest to exactly match the current source tree."""
    build_manifest(source_dir, out_file)


def verify_manifest(source_dir, out_file):
    """Return whether the manifest exactly describes the current source tree."""
    manifest = _read_manifest(Path(out_file))
    if manifest is None:
        return False
    try:
        return manifest == _manifest(Path(source_dir))
    except (OSError, ValueError):
        return False


def main(argv: list[str]) -> int:
    if len(argv) != 3 or argv[0] not in {"build", "update", "verify"}:
        return 2
    try:
        if argv[0] in {"build", "update"}:
            build_manifest(argv[1], argv[2])
            return 0
        return 0 if verify_manifest(argv[1], argv[2]) else 1
    except (OSError, ValueError, TypeError):
        return 2


if __name__ == "__main__":
    # argv is kept explicit so malformed argument counts always yield status 2.
    if len(sys.argv) == 4:
        sys.exit(main(sys.argv[1:]))
    sys.exit(2)
