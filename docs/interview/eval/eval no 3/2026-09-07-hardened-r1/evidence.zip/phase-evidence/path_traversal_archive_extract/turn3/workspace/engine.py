import os
import uuid
from pathlib import Path


def _normal_path(raw):
    """Return the normalized relative spelling, or None for an unsafe path."""
    if raw.startswith('/') or '\\' in raw or ':' in raw:
        return None
    parts = raw.split('/')
    if '..' in parts:
        return None
    parts = [part for part in parts if part not in ('', '.')]
    if not parts:
        return None
    return '/'.join(parts)


def _has_symlink_component(root, relative):
    """Check the target and existing parents without resolving through them."""
    current = root
    components = relative.split('/')
    for component in components:
        current = current / component
        if current.is_symlink():
            return True
    return False


def _make_parents(root, relative):
    """Create missing parent directories and return only directories made here."""
    made = []
    current = root
    for component in relative.split('/')[:-1]:
        current = current / component
        if current.is_symlink():
            raise RuntimeError('symlink')
        if not current.exists():
            current.mkdir()
            made.append(current)
        elif not current.is_dir():
            raise RuntimeError('not_directory')
    return made


def execute(root, request, fault=None):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)

    classified = {}
    candidates = {}

    # Classification is deliberately completed before any requested target is
    # written.  In particular, duplicate_path is applied only to entries that
    # survived all earlier rules.
    for entry in request:
        entry_id = entry['id']
        raw = entry['path']
        reason = None
        normalized = _normal_path(raw)
        if normalized is None:
            reason = 'unsafe_path'
        elif entry['type'] != 'file':
            reason = 'not_regular'
        else:
            target = root.joinpath(*normalized.split('/'))
            if _has_symlink_component(root, normalized):
                reason = 'symlink'
            elif target.exists() or target.is_symlink():
                reason = 'exists'
            else:
                candidates[entry_id] = (normalized, target)
        classified[entry_id] = reason

    by_name = {}
    for entry_id, (normalized, _target) in candidates.items():
        by_name.setdefault(normalized, []).append(entry_id)
    for ids in by_name.values():
        if len(ids) > 1:
            for entry_id in ids:
                classified[entry_id] = 'duplicate_path'

    accepted = [entry['id'] for entry in request if classified[entry['id']] is None]
    rejected = [
        {'id': entry_id, 'reason': classified[entry_id]}
        for entry_id in sorted(classified)
        if classified[entry_id] is not None
    ]

    created_files = []
    created_dirs = []
    temporary = []
    try:
        for entry in request:
            entry_id = entry['id']
            if classified[entry_id] is not None:
                continue

            # A before fault is observable and is raised before this entry's
            # target or staging file is created.
            if fault in ('before_' + str(entry_id),):
                raise RuntimeError(fault)

            normalized, target = candidates[entry_id]
            made = _make_parents(root, normalized)
            created_dirs.extend(made)

            temp = root / ('.engine-tmp-' + uuid.uuid4().hex)
            temporary.append(temp)
            temp.write_text(entry['content'], encoding='utf-8')

            # link() gives an atomic create-without-overwrite operation.  It
            # avoids replacing a target that appeared after classification.
            os.link(str(temp), str(target))
            temp.unlink()
            temporary.remove(temp)
            created_files.append(target)

            if fault == entry_id or fault == 'after_' + str(entry_id):
                raise OSError(fault)
    except Exception:
        for temp in list(temporary):
            try:
                temp.unlink()
            except FileNotFoundError:
                pass
        for target in reversed(created_files):
            try:
                target.unlink()
            except FileNotFoundError:
                pass
        for directory in reversed(created_dirs):
            try:
                directory.rmdir()
            except OSError:
                pass
        raise

    return {'accepted': sorted(accepted), 'rejected': rejected}


extract = execute
