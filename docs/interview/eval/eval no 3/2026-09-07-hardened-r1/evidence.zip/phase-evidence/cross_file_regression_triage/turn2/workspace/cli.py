import json
import os
import sys
import tempfile
from pathlib import Path

from loader import load
from solution import solve


def main():
    if len(sys.argv) != 3:
        return 2
    input_path, output_path = sys.argv[1], sys.argv[2]
    try:
        data = load(Path(input_path).read_text(encoding="utf-8"))
        result = solve(data)
        encoded = json.dumps(result, ensure_ascii=False, separators=(",", ":"), sort_keys=False)
        destination = Path(output_path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix=f".{destination.name}.", dir=str(destination.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as stream:
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, destination)
        except Exception:
            try:
                os.unlink(temporary)
            except OSError:
                pass
            raise
        return 0
    except (ValueError, OSError, UnicodeError, TypeError, KeyError):
        return 1


if __name__ == "__main__":
    sys.exit(main())
