"""Dependency version selection implementation."""

import re
from functools import total_ordering


_VERSION_RE = re.compile(
    r"^(0|[1-9][0-9]*)\."
    r"(0|[1-9][0-9]*)\."
    r"(0|[1-9][0-9]*)"
    r"(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?"
    r"(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$"
)


@total_ordering
class _Version:
    __slots__ = ("text", "major", "minor", "patch", "pre")

    def __init__(self, text):
        if not isinstance(text, str):
            raise ValueError("version must be a string")
        match = _VERSION_RE.fullmatch(text)
        if match is None:
            raise ValueError("invalid version")
        self.text = text
        self.major, self.minor, self.patch = (int(match.group(i)) for i in (1, 2, 3))
        raw_pre = match.group(4)
        self.pre = () if raw_pre is None else tuple(
            int(part) if part.isdigit() else part for part in raw_pre.split(".")
        )
        if any(isinstance(part, int) and str(part) != raw for part, raw in zip(
            self.pre, raw_pre.split(".") if raw_pre else ()
        )):
            raise ValueError("invalid version")

    def _key(self):
        # A release is newer than any prerelease of the same base version.
        pre_key = (1,) if not self.pre else (0, tuple(
            (0, part) if isinstance(part, int) else (1, part)
            for part in self.pre
        ))
        return (self.major, self.minor, self.patch, pre_key)

    def __eq__(self, other):
        return isinstance(other, _Version) and self._key() == other._key()

    def __lt__(self, other):
        if not isinstance(other, _Version):
            return NotImplemented
        return self._key() < other._key()

    def __hash__(self):
        return hash(self._key())


def _versions(values, label):
    if not isinstance(values, list):
        raise ValueError(label + " must be an array")
    parsed = []
    for value in values:
        try:
            parsed.append((value, _Version(value)))
        except ValueError as exc:
            raise ValueError("invalid version in " + label) from exc
    return parsed


def solve(data):
    """Return the highest available version satisfying every requirement."""
    if not isinstance(data, dict):
        raise ValueError("data must be an object")
    catalog = data.get("catalog")
    requirements = data.get("requirements")
    yanked = data.get("yanked", {})
    if not isinstance(catalog, dict) or not isinstance(requirements, list):
        raise ValueError("invalid input")
    if not isinstance(yanked, dict):
        raise ValueError("yanked must be an object")

    parsed_catalog = {}
    for name, values in catalog.items():
        if not isinstance(name, str):
            raise ValueError("component name must be a string")
        parsed_catalog[name] = _versions(values, "catalog")
    parsed_yanked = {}
    for name, values in yanked.items():
        if not isinstance(name, str):
            raise ValueError("component name must be a string")
        parsed_yanked[name] = {version for version, _ in _versions(values, "yanked")}

    requested = {}
    for requirement in requirements:
        if not isinstance(requirement, dict):
            raise ValueError("requirement must be an object")
        name = requirement.get("name")
        minimum = requirement.get("min")
        maximum = requirement.get("max")
        if not isinstance(name, str) or not isinstance(minimum, str):
            raise ValueError("invalid requirement")
        lower = _Version(minimum)
        upper = None if maximum is None else _Version(maximum)
        if upper is not None and lower >= upper:
            raise ValueError("empty version range")
        if name in requested:
            old_lower, old_upper = requested[name]
            if lower > old_lower:
                old_lower = lower
            if old_upper is None or (upper is not None and upper < old_upper):
                old_upper = upper
            requested[name] = (old_lower, old_upper)
        else:
            requested[name] = (lower, upper)

    result = {}
    for name, (lower, upper) in requested.items():
        if name not in parsed_catalog:
            raise ValueError("unknown component")
        candidates = {}
        for original, version in parsed_catalog[name]:
            if original in parsed_yanked.get(name, set()):
                continue
            if version >= lower and (upper is None or version < upper):
                candidates[version] = original
        if not candidates:
            raise ValueError("no matching version")
        result[name] = candidates[max(candidates)]
    return result
