"""Atomic JSON output storage."""
import json
import os
import tempfile
from pathlib import Path


def encode(data):
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"), sort_keys=False).encode("utf-8")


def save(path, data):
    target = Path(path)
    payload = encode(data)
    parent = target.parent
    fd, temporary = tempfile.mkstemp(prefix="." + target.name + ".", dir=str(parent))
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, target)
    except Exception:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise
