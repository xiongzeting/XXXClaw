def latest(rows):
    """Select the highest revision for each tenant/id event identity."""
    selected = {}
    for row in rows:
        key = (row["tenant"], row["id"])
        old = selected.get(key)
        if old is None or row["revision"] > old["revision"]:
            selected[key] = row
        elif row["revision"] == old["revision"] and row != old:
            raise ValueError("conflicting event revision")
    return list(selected.values())
